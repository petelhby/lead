// src/app/(app)/layout.tsx
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import dynamic from "next/dynamic";

// Весь UI-обвес грузим на клиенте (исключаем SSR-конфликты)
const ClientAppShell = dynamic(() => import("./ClientAppShell"), { ssr: false });

export default function AppLayout({ children }: { children: React.ReactNode }) {
  // Серверная защита приватной зоны
  const token = cookies().get("token")?.value;
  if (!token) redirect("/auth");

  // Сервер отдаёт «пустышку», клиент дорисует Topbar+контейнер
  return (
    <div suppressHydrationWarning>
      <ClientAppShell>{children}</ClientAppShell>
    </div>
  );
}
